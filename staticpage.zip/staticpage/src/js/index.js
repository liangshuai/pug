(function( $ ){
	$( function(){
		$('.carousel').css('visibility', 'visible');
		$( document ).trigger( "enhance");
	});
}( jQuery ));